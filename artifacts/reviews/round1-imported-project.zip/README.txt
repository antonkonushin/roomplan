RoomPlan portable project v1. project.json contains metric geometry and paths to every original source and generated asset. Files are never executable. Open the ZIP in RoomPlan to continue editing.
